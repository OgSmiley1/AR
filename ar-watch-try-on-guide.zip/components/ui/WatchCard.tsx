import React from 'react';
import { useSpring, animated } from '@react-spring/web';
import { useStore } from '../../store.ts';
import type { Watch } from '../../types.ts';

interface WatchCardProps {
  watch: Watch;
}

export const WatchCard = ({ watch }: WatchCardProps) => {
  const { selectedWatch, selectWatch } = useStore();
  const isSelected = selectedWatch?.id === watch.id;

  const props = useSpring({
    transform: isSelected ? 'scale(1.05)' : 'scale(1)',
    boxShadow: isSelected ? '0 0 15px rgba(56, 189, 248, 0.5)' : '0 0 0px rgba(56, 189, 248, 0)',
    config: { tension: 300, friction: 10 },
  });

  return (
    <animated.div
      style={props}
      onClick={() => selectWatch(watch)}
      className={`bg-gray-800/50 p-4 rounded-lg border cursor-pointer transition-colors duration-300 ${
        isSelected ? 'border-cyan-400' : 'border-gray-700 hover:border-gray-600'
      }`}
    >
      <img src={watch.image} alt={watch.name} className="w-full h-40 object-contain mb-4" />
      <div className="text-left">
        <p className="text-sm font-semibold text-gray-400">{watch.collection.toUpperCase()}</p>
        <h4 className="text-lg font-bold text-white">{watch.name}</h4>
        <p className="text-md text-cyan-400 mt-1">{watch.price}</p>
      </div>
    </animated.div>
  );
};