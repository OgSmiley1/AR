import React from 'react';
import { useSpring, animated } from '@react-spring/web';
import { CameraIcon } from '../icons.tsx';

interface PermissionModalProps {
  onGrant: () => void;
  onDeny: () => void;
}

export const PermissionModal = ({ onGrant, onDeny }: PermissionModalProps) => {
  const props = useSpring({
    from: { opacity: 0, transform: 'scale(0.9)' },
    to: { opacity: 1, transform: 'scale(1)' },
  });

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
      <animated.div style={props} className="bg-gray-800 rounded-xl shadow-2xl border border-gray-700 max-w-md w-full text-center p-8">
        <CameraIcon className="w-16 h-16 mx-auto text-cyan-400 mb-4" />
        <h2 className="text-3xl font-bold mb-2 text-white">Virtual Try-On</h2>
        <p className="text-gray-400 mb-6">
          To experience the Vacheron Constantin collection in augmented reality, please grant access to your camera.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={onGrant}
            className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-6 rounded-lg transition-all transform hover:scale-105"
          >
            Grant Access
          </button>
          <button
            onClick={onDeny}
            className="w-full bg-gray-700 hover:bg-gray-600 text-gray-300 font-bold py-3 px-6 rounded-lg transition-all"
          >
            Maybe Later
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-6">Your camera is only used for the AR experience and no data is stored.</p>
      </animated.div>
    </div>
  );
};