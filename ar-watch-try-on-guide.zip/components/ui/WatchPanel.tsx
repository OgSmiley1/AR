import React from 'react';
import { useStore } from '../../store.ts';
import { WatchCard } from './WatchCard.tsx';

export const WatchPanel = () => {
  const watches = useStore((state) => state.watches);

  return (
    <div>
      <h2 className="text-3xl font-bold text-white mb-2">Collections</h2>
      <p className="text-gray-400 mb-6">Select a timepiece to experience it in augmented reality.</p>
      <div className="grid grid-cols-1 gap-4">
        {watches.map(watch => (
          <WatchCard key={watch.id} watch={watch} />
        ))}
      </div>
    </div>
  );
};