import React, { useRef, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { Environment } from '@react-three/drei';
import { useStore } from '../../store.ts';
import HandTracker from './HandTracker.ts';
import { WatchModel } from './WatchModel.tsx';
import { Loader } from '../ui/Loader.tsx';

export const ARViewport = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const handTrackerRef = useRef<HandTracker | null>(null);
  const { setHandLandmarks, isLoading, setLoading } = useStore();

  useEffect(() => {
    const tracker = new HandTracker((landmarks) => {
      setHandLandmarks(landmarks);
    });
    handTrackerRef.current = tracker;

    const setupCamera = async () => {
      try {
        setLoading(true);
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 1280, height: 720, facingMode: 'user' },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current?.play();
            if (handTrackerRef.current) {
              handTrackerRef.current.setVideo(videoRef.current!);
              handTrackerRef.current.start();
            }
             setLoading(false);
          };
        }
      } catch (err) {
        console.error("Error accessing camera: ", err);
        setLoading(false);
        // Handle camera permission denial
      }
    };
    setupCamera();

    return () => {
      videoRef.current?.srcObject &&
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
    };
  }, [setHandLandmarks, setLoading]);

  return (
    <div id="ar-canvas" className="w-full h-full relative">
      {isLoading && <Loader text="Starting camera..." />}
      <video ref={videoRef} className="w-full h-full object-cover transform -scale-x-100" playsInline muted autoPlay />
      <div className="absolute inset-0">
        <Canvas
          camera={{ position: [0, 0, 1.5], fov: 50 }}
          gl={{ alpha: true, antialias: true }}
          style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
        >
          <ambientLight intensity={1.5} />
          <Environment preset="city" />
          <WatchModel />
        </Canvas>
      </div>
    </div>
  );
};