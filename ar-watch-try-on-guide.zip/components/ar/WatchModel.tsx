import React, { useRef, useMemo } from 'react';
import { useLoader, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { useStore } from '../../store.ts';

export const WatchModel = () => {
  const { selectedWatch, handLandmarks } = useStore();
  const modelRef = useRef<THREE.Group>(null);
  
  const gltf = useLoader(GLTFLoader, selectedWatch?.modelUrl || '');
  
  const model = useMemo(() => {
    if (!gltf) return null;
    const scene = gltf.scene.clone();
    
    // Normalize model
    const box = new THREE.Box3().setFromObject(scene);
    const size = box.getSize(new THREE.Vector3()).length();
    const center = box.getCenter(new THREE.Vector3());
    
    scene.position.x += (scene.position.x - center.x);
    scene.position.y += (scene.position.y - center.y);
    scene.position.z += (scene.position.z - center.z);
    
    // Scale to a consistent size (e.g., 0.15 units)
    scene.scale.setScalar(0.15 / size);
    
    return scene;
  }, [gltf]);


  useFrame((state, delta) => {
    if (!modelRef.current || !handLandmarks) {
        if(modelRef.current) modelRef.current.visible = false;
        return;
    }
    modelRef.current.visible = true;

    // Landmarks for wrist and hand
    const wrist = handLandmarks[0];
    const pinkyKnuckle = handLandmarks[17];
    const indexKnuckle = handLandmarks[5];
    
    // Convert normalized 2D screen coordinates to 3D world coordinates
    const viewportCoord = (landmark: any, z: number) => 
        new THREE.Vector3(
          (landmark.x - 0.5) * 2 * (state.viewport.width / state.viewport.height),
          -(landmark.y - 0.5) * 2,
          z
        );

    const wristPos = viewportCoord(wrist, -1);
    const indexPos = viewportCoord(indexKnuckle, -1);
    const pinkyPos = viewportCoord(pinkyKnuckle, -1);
    
    // Position the watch at the wrist
    modelRef.current.position.lerp(wristPos, 0.5);

    // Orient the watch based on hand direction
    const handXAxis = new THREE.Vector3().subVectors(pinkyPos, indexPos).normalize();
    const handZAxis = new THREE.Vector3().crossVectors(handXAxis, new THREE.Vector3(0, 1, 0)).normalize();
    const handYAxis = new THREE.Vector3().crossVectors(handZAxis, handXAxis).normalize();

    const targetQuaternion = new THREE.Quaternion().setFromRotationMatrix(
        new THREE.Matrix4().makeBasis(handXAxis, handYAxis, handZAxis)
    );
    
    // Add a rotation to make the watch face up
    const correctionQuaternion = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, Math.PI, 0));
    targetQuaternion.multiply(correctionQuaternion);

    modelRef.current.quaternion.slerp(targetQuaternion, 0.2);
  });

  if (!model) return null;

  return <primitive ref={modelRef} object={model} />;
};