import { HandLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';

class HandTracker {
  private handLandmarker: HandLandmarker | null = null;
  private video: HTMLVideoElement | null = null;
  private lastVideoTime = -1;
  private onResults: (landmarks: any) => void;

  constructor(onResultsCallback: (landmarks: any) => void) {
    this.onResults = onResultsCallback;
    this.initialize();
  }

  private async initialize() {
    try {
      const vision = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.9/wasm'
      );
      this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
          delegate: 'GPU',
        },
        runningMode: 'VIDEO',
        numHands: 1,
      });
      console.log('Hand Landmarker initialized.');
    } catch (error) {
      console.error('Failed to initialize Hand Landmarker:', error);
    }
  }

  public setVideo(videoElement: HTMLVideoElement) {
    this.video = videoElement;
  }

  public start() {
    if (this.video) {
      this.predictWebcam();
    }
  }

  private predictWebcam = () => {
    if (!this.handLandmarker || !this.video || this.video.paused || this.video.ended) {
      requestAnimationFrame(this.predictWebcam);
      return;
    }

    const currentTime = this.video.currentTime;
    if (currentTime > this.lastVideoTime) {
      this.lastVideoTime = currentTime;
      const results = this.handLandmarker.detectForVideo(this.video, Date.now());
      if (results.landmarks && results.landmarks.length > 0) {
        this.onResults(results.landmarks[0]);
      } else {
        this.onResults(null);
      }
    }
    requestAnimationFrame(this.predictWebcam);
  };
}

export default HandTracker;
