import { create } from 'zustand';
import type { Watch, HandLandmarks } from './types';

interface AppState {
  watches: Watch[];
  selectedWatch: Watch | null;
  handLandmarks: HandLandmarks | null;
  isLoading: boolean;
  loadWatches: () => Promise<void>;
  selectWatch: (watch: Watch | null) => void;
  setHandLandmarks: (landmarks: HandLandmarks | null) => void;
  setLoading: (loading: boolean) => void;
}

export const useStore = create<AppState>((set) => ({
  watches: [],
  selectedWatch: null,
  handLandmarks: null,
  isLoading: true,
  loadWatches: async () => {
    try {
      const response = await fetch('/data/watches.json');
      if (!response.ok) {
        throw new Error('Failed to fetch watches');
      }
      const watchesData: Watch[] = await response.json();
      set({ watches: watchesData, selectedWatch: watchesData[0] || null });
    } catch (error) {
      console.error(error);
    }
  },
  selectWatch: (watch) => set({ selectedWatch: watch }),
  setHandLandmarks: (landmarks) => set({ handLandmarks: landmarks }),
  setLoading: (loading) => set({ isLoading: loading }),
}));
