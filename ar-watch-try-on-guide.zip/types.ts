import type { Landmark } from '@mediapipe/tasks-vision';

export interface Watch {
  id: string;
  name: string;
  collection: string;
  price: string;
  image: string;
  modelUrl: string;
}

export type HandLandmarks = Landmark[];
