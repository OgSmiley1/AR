
import React, { useState, useEffect, Suspense } from 'react';
import { ARViewport } from './components/ar/ARViewport.tsx';
import { WatchPanel } from './components/ui/WatchPanel.tsx';
import { useStore } from './store.ts';
import { PermissionModal } from './components/ui/PermissionModal.tsx';
import { Loader } from './components/ui/Loader.tsx';
import { CameraIcon } from './components/icons.tsx';

const App = () => {
  const { loadWatches, selectedWatch } = useStore();
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(true);

  useEffect(() => {
    loadWatches();
  }, [loadWatches]);

  const handlePermissionGranted = () => {
    setPermissionGranted(true);
    setShowPermissionModal(false);
  };
  
  const handlePermissionDenied = () => {
    setShowPermissionModal(false);
  };
  
  const handleSnapshot = () => {
    const video = document.querySelector('video');
    const canvas = document.querySelector('#ar-canvas canvas');
    
    // Use instanceof for runtime type checking, which is valid JavaScript
    if (!(video instanceof HTMLVideoElement) || !(canvas instanceof HTMLCanvasElement)) {
      console.error("Required video or canvas element not found for snapshot.");
      return;
    }

    const compositeCanvas = document.createElement('canvas');
    compositeCanvas.width = video.videoWidth;
    compositeCanvas.height = video.videoHeight;
    const ctx = compositeCanvas.getContext('2d');
    
    if(!ctx) return;

    // Flip the video context horizontally to match the mirrored view
    ctx.translate(video.videoWidth, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
    
    // Reset transform to draw the 3D canvas normally
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(canvas, 0, 0, video.videoWidth, video.videoHeight);

    const link = document.createElement('a');
    link.download = `${selectedWatch?.name.replace(/ /g, '_') || 'AR_Watch'}_Try_On.png`;
    link.href = compositeCanvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="w-screen h-screen flex flex-col md:flex-row bg-gray-900 text-gray-100">
      {showPermissionModal && !permissionGranted && (
        <PermissionModal onGrant={handlePermissionGranted} onDeny={handlePermissionDenied} />
      )}

      <main className="flex-grow h-full w-full relative">
        {!permissionGranted && (
          <div className="absolute inset-0 bg-black/50 z-10 flex flex-col items-center justify-center text-center p-4">
             <div className="p-8 bg-gray-800 rounded-lg shadow-2xl border border-gray-700">
                <CameraIcon className="w-16 h-16 mx-auto text-cyan-400 mb-4" />
                <h2 className="text-2xl font-bold mb-2">Camera Access Required</h2>
                <p className="text-gray-400 mb-6">Please allow camera access to begin the AR experience.</p>
                <button 
                  onClick={() => setShowPermissionModal(true)}
                  className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-6 rounded-lg transition-all"
                >
                  Grant Permission
                </button>
             </div>
          </div>
        )}
        <Suspense fallback={<Loader text="Initializing AR Engine..." />}>
          {permissionGranted && <ARViewport />}
        </Suspense>
        
        {selectedWatch && permissionGranted && (
           <button onClick={handleSnapshot} className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 bg-white/20 backdrop-blur-md text-white font-bold py-3 px-6 rounded-full border border-white/30 hover:bg-white/30 transition-all flex items-center gap-2">
             <CameraIcon className="w-6 h-6" />
             Capture
           </button>
        )}
      </main>

      <aside className="w-full md:w-80 lg:w-96 bg-gray-900/80 backdrop-blur-sm border-t md:border-t-0 md:border-l border-gray-800/50 p-4 md:p-6 h-1/3 md:h-full overflow-y-auto">
        <WatchPanel />
      </aside>
    </div>
  );
};

export default App;