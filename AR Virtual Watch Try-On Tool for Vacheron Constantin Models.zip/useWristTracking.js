import { useState, useEffect, useRef, useCallback } from 'react';
import { Hands } from '@mediapipe/hands';
import { Camera } from '@mediapipe/camera_utils';

export const useWristTracking = (videoElement) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [wristData, setWristData] = useState(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState(null);
  
  const handsRef = useRef(null);
  const cameraRef = useRef(null);
  const lastWristDataRef = useRef(null);
  const stabilizationBufferRef = useRef([]);

  // Stabilization filter for smooth tracking
  const stabilizeWristData = useCallback((newData) => {
    if (!newData) return null;

    const buffer = stabilizationBufferRef.current;
    buffer.push(newData);
    
    // Keep only last 5 frames for smoothing
    if (buffer.length > 5) {
      buffer.shift();
    }

    // Calculate average position for stability
    const avgX = buffer.reduce((sum, data) => sum + data.x, 0) / buffer.length;
    const avgY = buffer.reduce((sum, data) => sum + data.y, 0) / buffer.length;
    const avgZ = buffer.reduce((sum, data) => sum + data.z, 0) / buffer.length;

    return {
      ...newData,
      x: avgX,
      y: avgY,
      z: avgZ,
      confidence: Math.min(...buffer.map(data => data.confidence))
    };
  }, []);

  // Calculate wrist orientation from hand landmarks
  const calculateWristOrientation = useCallback((landmarks) => {
    if (!landmarks || landmarks.length < 21) return null;

    // MediaPipe hand landmarks indices
    const wrist = landmarks[0];           // Wrist point
    const middleMcp = landmarks[9];       // Middle finger MCP
    const indexMcp = landmarks[5];        // Index finger MCP
    const pinkyMcp = landmarks[17];       // Pinky MCP

    // Calculate hand orientation vectors
    const handDirection = {
      x: middleMcp.x - wrist.x,
      y: middleMcp.y - wrist.y,
      z: middleMcp.z - wrist.z
    };

    const handWidth = {
      x: pinkyMcp.x - indexMcp.x,
      y: pinkyMcp.y - indexMcp.y,
      z: pinkyMcp.z - indexMcp.z
    };

    // Cross product for normal vector (watch face orientation)
    const normal = {
      x: handDirection.y * handWidth.z - handDirection.z * handWidth.y,
      y: handDirection.z * handWidth.x - handDirection.x * handWidth.z,
      z: handDirection.x * handWidth.y - handDirection.y * handWidth.x
    };

    // Normalize the normal vector
    const normalLength = Math.sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
    if (normalLength > 0) {
      normal.x /= normalLength;
      normal.y /= normalLength;
      normal.z /= normalLength;
    }

    // Calculate rotation angles
    const rotationX = Math.atan2(normal.y, normal.z);
    const rotationY = Math.atan2(-normal.x, Math.sqrt(normal.y * normal.y + normal.z * normal.z));
    const rotationZ = Math.atan2(handWidth.y, handWidth.x);

    // Estimate wrist size based on hand landmarks
    const wristWidth = Math.sqrt(
      Math.pow(indexMcp.x - pinkyMcp.x, 2) + 
      Math.pow(indexMcp.y - pinkyMcp.y, 2)
    );

    return {
      position: {
        x: wrist.x,
        y: wrist.y,
        z: wrist.z
      },
      rotation: {
        x: rotationX,
        y: rotationY,
        z: rotationZ
      },
      normal: normal,
      wristWidth: wristWidth,
      confidence: Math.min(wrist.visibility || 1, 0.8) // Conservative confidence
    };
  }, []);

  // MediaPipe results callback
  const onResults = useCallback((results) => {
    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      // Process the first detected hand (can be extended for multi-hand)
      const landmarks = results.multiHandLandmarks[0];
      const handedness = results.multiHandedness[0];
      
      // Check if it's the right hand (preferred for watch wearing)
      const isRightHand = handedness.label === 'Right';
      
      const wristOrientation = calculateWristOrientation(landmarks);
      
      if (wristOrientation && wristOrientation.confidence > 0.5) {
        const rawWristData = {
          ...wristOrientation,
          isRightHand,
          timestamp: Date.now(),
          landmarks: landmarks
        };

        // Apply stabilization
        const stabilizedData = stabilizeWristData(rawWristData);
        
        setWristData(stabilizedData);
        lastWristDataRef.current = stabilizedData;
        setIsTracking(true);
      } else {
        // Low confidence, gradually fade out tracking
        setTimeout(() => {
          if (Date.now() - (lastWristDataRef.current?.timestamp || 0) > 500) {
            setIsTracking(false);
          }
        }, 500);
      }
    } else {
      // No hands detected
      setTimeout(() => {
        if (Date.now() - (lastWristDataRef.current?.timestamp || 0) > 300) {
          setIsTracking(false);
          setWristData(null);
        }
      }, 300);
    }
  }, [calculateWristOrientation, stabilizeWristData]);

  // Initialize MediaPipe Hands
  const initializeTracking = useCallback(async () => {
    try {
      setError(null);
      
      const hands = new Hands({
        locateFile: (file) => {
          return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
        }
      });

      hands.setOptions({
        maxNumHands: 2,
        modelComplexity: 1,
        minDetectionConfidence: 0.7,
        minTrackingConfidence: 0.5
      });

      hands.onResults(onResults);
      handsRef.current = hands;

      if (videoElement) {
        const camera = new Camera(videoElement, {
          onFrame: async () => {
            if (handsRef.current) {
              await handsRef.current.send({ image: videoElement });
            }
          },
          width: 1280,
          height: 720
        });

        cameraRef.current = camera;
        await camera.start();
      }

      setIsInitialized(true);
      console.log('Wrist tracking initialized successfully');
    } catch (err) {
      console.error('Failed to initialize wrist tracking:', err);
      setError(`Tracking initialization failed: ${err.message}`);
    }
  }, [videoElement, onResults]);

  // Start tracking
  const startTracking = useCallback(() => {
    if (cameraRef.current) {
      cameraRef.current.start();
    }
  }, []);

  // Stop tracking
  const stopTracking = useCallback(() => {
    if (cameraRef.current) {
      cameraRef.current.stop();
    }
    setIsTracking(false);
    setWristData(null);
  }, []);

  // Initialize when video element is available
  useEffect(() => {
    if (videoElement && !isInitialized) {
      initializeTracking();
    }

    return () => {
      if (cameraRef.current) {
        cameraRef.current.stop();
      }
    };
  }, [videoElement, isInitialized, initializeTracking]);

  return {
    isInitialized,
    isTracking,
    wristData,
    error,
    startTracking,
    stopTracking,
    initializeTracking
  };
};

