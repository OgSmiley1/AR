import { Button } from '@/components/ui/button.jsx';
import { motion } from 'framer-motion';
import { watchModels } from '../data/watches.js';

const WatchSelection = ({ onSelectWatch, onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-black">
      {/* Header */}
      <header className="flex justify-between items-center p-6 md:p-8">
        <div className="text-2xl md:text-3xl font-light text-white tracking-wider">
          VACHERON CONSTANTIN
        </div>
        <Button
          onClick={onBack}
          variant="ghost"
          className="text-white hover:text-gold-400 hover:bg-white/10"
        >
          ← Back
        </Button>
      </header>

      {/* Main Content */}
      <div className="px-6 md:px-12 lg:px-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-thin text-white mb-4 tracking-wide">
            SELECT YOUR TIMEPIECE
          </h1>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            Choose from our curated selection of iconic Vacheron Constantin watches
          </p>
        </motion.div>

        {/* Watch Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {watchModels.map((watch, index) => (
            <motion.div
              key={watch.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className={`relative overflow-hidden rounded-lg bg-gradient-to-br ${watch.backgroundColor} 
                         shadow-2xl hover:shadow-3xl transition-all duration-500 group
                         hover:scale-105 cursor-pointer`}
              onClick={() => onSelectWatch(watch)}
            >
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-4 right-4 w-16 h-16 border border-white/20 rotate-45"></div>
                <div className="absolute bottom-4 left-4 w-12 h-12 border border-white/20 rotate-12"></div>
              </div>

              <div className="relative z-10 p-8">
                {/* Watch Image */}
                <div className="mb-6 flex justify-center">
                  <div className="w-48 h-48 md:w-56 md:h-56 rounded-full bg-white/10 backdrop-blur-sm 
                                flex items-center justify-center overflow-hidden">
                    <img
                      src={watch.image}
                      alt={watch.name}
                      className="w-40 h-40 md:w-48 md:h-48 object-contain filter drop-shadow-2xl
                               group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>

                {/* Watch Info */}
                <div className="text-center text-white">
                  <h3 className="text-xl md:text-2xl font-light mb-2 tracking-wide">
                    {watch.name}
                  </h3>
                  <p className="text-sm text-white/70 mb-1 uppercase tracking-wider">
                    {watch.collection}
                  </p>
                  <p className="text-sm text-white/70 mb-4">
                    {watch.size} • {watch.material}
                  </p>
                  <p className="text-2xl font-light text-gold-400 mb-6">
                    {watch.price}
                  </p>
                  
                  <Button
                    className="bg-white/20 hover:bg-white/30 text-white border border-white/30 
                             hover:border-white/50 backdrop-blur-sm rounded-none px-8 py-3
                             uppercase tracking-wider font-medium transition-all duration-300
                             hover:scale-105"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectWatch(watch);
                    }}
                  >
                    Try On
                  </Button>
                </div>
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent 
                            opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Text */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="text-center mt-16 text-xs text-white/60 uppercase tracking-widest"
        >
          270 Years of Horological Excellence
        </motion.div>
      </div>
    </div>
  );
};

export default WatchSelection;

