import React, { useState, useEffect } from 'react';
import { Camera, RotateCcw, Download, Info, Play, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

const SimpleARDemo = () => {
  const [selectedWatch, setSelectedWatch] = useState('overseas');
  const [watchScale, setWatchScale] = useState(1);
  const [showInfo, setShowInfo] = useState(false);
  const [isARActive, setIsARActive] = useState(false);
  const [isTracking, setIsTracking] = useState(false);
  const [watchPosition, setWatchPosition] = useState({ x: 50, y: 50 });

  // Watch collection data
  const watchCollection = {
    overseas: {
      name: 'Overseas Self-Winding',
      size: '41mm',
      material: 'Stainless Steel',
      price: '$27,700',
      description: 'The spirit of travel embodied in a luxury sports watch',
      image: '⌚', // Using emoji as placeholder
      color: '#C0C0C0'
    },
    patrimony: {
      name: 'Patrimony Moon Phase',
      size: '42.5mm', 
      material: 'White Gold',
      price: '$55,000',
      description: 'Circular perfection with moon phase complication',
      image: '⌚',
      color: '#F5F5DC'
    },
    traditionnelle: {
      name: 'Traditionnelle Manual-Winding',
      size: '38mm',
      material: 'Rose Gold', 
      price: '$32,000',
      description: 'Pure horological tradition in contemporary form',
      image: '⌚',
      color: '#E8B4B8'
    },
    historiques: {
      name: 'Historiques American 1921',
      size: '40mm',
      material: 'Platinum',
      price: '$78,000', 
      description: 'Iconic cushion-shaped case from 1921',
      image: '⌚',
      color: '#E5E4E2'
    }
  };

  // Simulate wrist tracking
  useEffect(() => {
    if (isARActive) {
      // Start tracking after a short delay
      const trackingTimer = setTimeout(() => {
        setIsTracking(true);
      }, 2000);

      // Animate watch position
      const animationInterval = setInterval(() => {
        const time = Date.now() * 0.001;
        setWatchPosition({
          x: 50 + Math.sin(time * 0.5) * 10,
          y: 50 + Math.cos(time * 0.3) * 8
        });
      }, 50);

      return () => {
        clearTimeout(trackingTimer);
        clearInterval(animationInterval);
      };
    } else {
      setIsTracking(false);
    }
  }, [isARActive]);

  // Start AR experience
  const startAR = () => {
    setIsARActive(true);
  };

  // Stop AR experience
  const stopAR = () => {
    setIsARActive(false);
  };

  // Take screenshot
  const takeScreenshot = () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 1280;
    canvas.height = 720;
    
    // Fill with dark background
    ctx.fillStyle = '#1a2332';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add gradient overlay
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, 'rgba(44, 62, 80, 0.8)');
    gradient.addColorStop(1, 'rgba(26, 35, 50, 0.9)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add watch representation
    ctx.fillStyle = watchCollection[selectedWatch].color;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 60 * watchScale, 0, 2 * Math.PI);
    ctx.fill();
    
    // Add text overlay
    ctx.fillStyle = '#D4AF37';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('VACHERON CONSTANTIN', canvas.width / 2, 80);
    
    ctx.font = '24px Arial';
    ctx.fillText(watchCollection[selectedWatch].name, canvas.width / 2, canvas.height - 80);
    
    ctx.font = '18px Arial';
    ctx.fillText(watchCollection[selectedWatch].price, canvas.width / 2, canvas.height - 50);
    
    // Download the screenshot
    const link = document.createElement('a');
    link.download = `vacheron-constantin-${selectedWatch}-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  // Switch watch model
  const switchWatch = (watchId) => {
    setSelectedWatch(watchId);
  };

  // Adjust watch scale
  const adjustScale = (delta) => {
    setWatchScale(prev => Math.max(0.5, Math.min(2.0, prev + delta)));
  };

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1a2332 0%, #2c3e50 50%, #1a2332 100%)' }}>
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-40 p-4">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold" style={{ color: '#D4AF37' }}>
            VACHERON CONSTANTIN
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInfo(!showInfo)}
              style={{ borderColor: '#D4AF37', color: '#D4AF37' }}
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mock Camera Feed Background */}
      {isARActive && (
        <div className="absolute inset-0 z-1" style={{ 
          background: 'linear-gradient(45deg, #4a5568 0%, #2d3748 50%, #1a202c 100%)',
          backgroundSize: '20px 20px',
          backgroundImage: `
            radial-gradient(circle at 25% 25%, rgba(255,255,255,0.1) 2px, transparent 2px),
            radial-gradient(circle at 75% 75%, rgba(255,255,255,0.05) 1px, transparent 1px)
          `
        }}>
          {/* Simulated hand/wrist area */}
          {isTracking && (
            <div 
              className="absolute transition-all duration-100"
              style={{
                left: `${watchPosition.x}%`,
                top: `${watchPosition.y}%`,
                transform: 'translate(-50%, -50%)',
                width: '120px',
                height: '120px',
                background: 'radial-gradient(circle, rgba(212, 175, 55, 0.2) 0%, rgba(212, 175, 55, 0.1) 50%, transparent 70%)',
                borderRadius: '50%',
                border: '2px solid rgba(212, 175, 55, 0.5)',
                animation: 'pulse 2s infinite'
              }}
            >
              {/* Watch representation */}
              <div 
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
                style={{
                  width: `${40 * watchScale}px`,
                  height: `${40 * watchScale}px`,
                  background: watchCollection[selectedWatch].color,
                  borderRadius: '50%',
                  border: '3px solid #333',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 2px 4px rgba(255,255,255,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: `${16 * watchScale}px`
                }}
              >
                <div style={{ 
                  width: '60%', 
                  height: '60%', 
                  background: 'white', 
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: `${8 * watchScale}px`,
                  color: '#333'
                }}>
                  VC
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Wrist Guide (when not tracking) */}
      {isARActive && !isTracking && (
        <div className="absolute inset-0 z-20 flex items-center justify-center">
          <div 
            className="relative"
            style={{
              width: '200px',
              height: '200px',
              border: '3px solid #D4AF37',
              borderRadius: '50%',
              opacity: 0.8,
              animation: 'pulse 2s ease-in-out infinite'
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center" style={{ color: '#F8F6F0' }}>
                <div className="text-sm font-medium">Position your wrist</div>
                <div className="text-xs opacity-75">in the center</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Watch Selection */}
      {isARActive && (
        <div className="absolute bottom-20 left-4 right-4 z-30">
          <div className="flex gap-2 justify-center mb-4 flex-wrap">
            {Object.entries(watchCollection).map(([id, watch]) => (
              <Button
                key={id}
                variant={selectedWatch === id ? "default" : "outline"}
                size="sm"
                onClick={() => switchWatch(id)}
                className="min-w-0 px-3"
                style={selectedWatch === id ? { 
                  backgroundColor: '#D4AF37', 
                  color: '#1a2332' 
                } : { 
                  borderColor: '#D4AF37', 
                  color: '#D4AF37' 
                }}
              >
                <div className="text-center">
                  <div className="text-xs font-medium">{watch.name.split(' ')[0]}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Controls */}
      {isARActive && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30">
          <div className="flex gap-3 p-3 rounded-full" style={{ 
            backgroundColor: 'rgba(26, 35, 50, 0.9)', 
            border: '1px solid rgba(212, 175, 55, 0.3)',
            backdropFilter: 'blur(10px)'
          }}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => adjustScale(-0.1)}
              style={{ borderColor: '#D4AF37', color: '#D4AF37' }}
            >
              -
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={takeScreenshot}
              style={{ borderColor: '#D4AF37', color: '#D4AF37' }}
            >
              <Download className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => adjustScale(0.1)}
              style={{ borderColor: '#D4AF37', color: '#D4AF37' }}
            >
              +
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setWatchScale(1)}
              style={{ borderColor: '#D4AF37', color: '#D4AF37' }}
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Start AR Button */}
      {!isARActive && (
        <div className="absolute inset-0 flex items-center justify-center z-30">
          <Card className="p-8 text-center max-w-md mx-4" style={{ 
            backgroundColor: 'rgba(26, 35, 50, 0.95)', 
            border: '1px solid rgba(212, 175, 55, 0.3)',
            color: '#F8F6F0'
          }}>
            <div className="mb-6">
              <div className="text-2xl font-bold mb-2" style={{ color: '#D4AF37' }}>
                AR Watch Try-On
              </div>
              <div className="mb-4" style={{ color: '#F8F6F0' }}>
                Experience Vacheron Constantin timepieces in augmented reality
              </div>
              <div className="text-xs p-2 rounded mb-4" style={{ 
                color: '#D4AF37', 
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                border: '1px solid rgba(212, 175, 55, 0.3)'
              }}>
                Demo Mode: Simulated AR experience
              </div>
            </div>
            
            <Button 
              onClick={startAR} 
              size="lg" 
              className="w-full mb-4"
              style={{ backgroundColor: '#D4AF37', color: '#1a2332' }}
            >
              <Play className="w-5 h-5 mr-2" />
              Start AR Demo
            </Button>
            
            <div className="text-xs" style={{ color: 'rgba(248, 246, 240, 0.7)' }}>
              Interactive watch models with realistic rendering
            </div>
          </Card>
        </div>
      )}

      {/* Watch Info Panel */}
      {showInfo && selectedWatch && (
        <div className="absolute top-16 right-4 z-40">
          <Card className="p-4 max-w-xs" style={{ 
            backgroundColor: 'rgba(26, 35, 50, 0.95)', 
            border: '1px solid rgba(212, 175, 55, 0.3)',
            color: '#F8F6F0'
          }}>
            <div className="space-y-2">
              <div className="font-semibold" style={{ color: '#D4AF37' }}>
                {watchCollection[selectedWatch].name}
              </div>
              <div className="flex gap-2">
                <Badge variant="secondary">{watchCollection[selectedWatch].size}</Badge>
                <Badge variant="outline">{watchCollection[selectedWatch].material}</Badge>
              </div>
              <div className="text-sm" style={{ color: 'rgba(248, 246, 240, 0.8)' }}>
                {watchCollection[selectedWatch].description}
              </div>
              <div className="text-lg font-bold" style={{ color: '#D4AF37' }}>
                {watchCollection[selectedWatch].price}
              </div>
              <Button 
                size="sm" 
                className="w-full mt-2"
                style={{ backgroundColor: '#D4AF37', color: '#1a2332' }}
                onClick={() => window.open('https://www.vacheron-constantin.com', '_blank')}
              >
                View on Official Site
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Status Indicators */}
      {isARActive && (
        <div className="absolute top-16 left-4 z-40 space-y-2">
          <Badge style={{ backgroundColor: '#D4AF37', color: '#1a2332' }}>
            Demo Mode: Active
          </Badge>
          <Badge variant={isTracking ? "default" : "secondary"}>
            Tracking: {isTracking ? "Simulated" : "Initializing"}
          </Badge>
          <Badge variant="outline" style={{ borderColor: '#D4AF37', color: '#D4AF37' }}>
            Scale: {Math.round(watchScale * 100)}%
          </Badge>
        </div>
      )}

      {/* Exit AR Button */}
      {isARActive && (
        <div className="absolute top-4 right-4 z-40">
          <Button
            variant="outline"
            size="sm"
            onClick={stopAR}
            style={{ borderColor: '#ef4444', color: '#ef4444' }}
          >
            <X className="w-4 h-4 mr-1" />
            Exit AR
          </Button>
        </div>
      )}

      {/* CSS Animation Styles */}
      <style jsx>{`
        @keyframes pulse {
          0% { opacity: 0.7; transform: translate(-50%, -50%) scale(1); }
          50% { opacity: 1; transform: translate(-50%, -50%) scale(1.05); }
          100% { opacity: 0.7; transform: translate(-50%, -50%) scale(1); }
        }
      `}</style>
    </div>
  );
};

export default SimpleARDemo;

