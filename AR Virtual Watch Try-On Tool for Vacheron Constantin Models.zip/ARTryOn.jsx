import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { motion } from 'framer-motion';
import { Camera, RotateCcw, Info, X, Download, Settings } from 'lucide-react';
import { watchModels } from '../data/watches.js';

const ARTryOn = ({ selectedWatch, onBack, onSelectDifferentWatch }) => {
  const [currentWatch, setCurrentWatch] = useState(selectedWatch);
  const [cameraActive, setCameraActive] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [watchSize, setWatchSize] = useState(50);
  const [watchRotation, setWatchRotation] = useState(0);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Initialize camera
  useEffect(() => {
    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: 'environment', // Back camera as specified
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setCameraActive(true);
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        // Fallback: show demo mode
        setCameraActive(false);
      }
    };

    initCamera();

    return () => {
      // Cleanup camera stream
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, []);

  const captureScreenshot = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const ctx = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Draw video frame
      ctx.drawImage(video, 0, 0);
      
      // Create download link
      const link = document.createElement('a');
      link.download = `vacheron-constantin-${currentWatch.id}-tryOn.png`;
      link.href = canvas.toDataURL();
      link.click();
    }
  };

  const resetPosition = () => {
    setWatchSize(50);
    setWatchRotation(0);
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Header */}
      <header className="absolute top-0 left-0 right-0 z-20 flex justify-between items-center p-4 bg-black/50 backdrop-blur-sm">
        <div className="text-xl font-light text-white tracking-wider">
          VACHERON CONSTANTIN
        </div>
        <div className="flex items-center space-x-4">
          <Button
            onClick={() => setShowDetails(true)}
            variant="ghost"
            size="sm"
            className="text-white hover:text-gold-400 hover:bg-white/10"
          >
            <Info className="w-4 h-4" />
          </Button>
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:text-gold-400 hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* Main AR View */}
      <div className="relative w-full h-screen">
        {/* Camera Feed */}
        {cameraActive ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center text-white">
              <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Camera Demo Mode</p>
              <p className="text-sm text-white/70">Position your wrist in the center</p>
            </div>
          </div>
        )}

        {/* AR Watch Overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <motion.div
            className="relative"
            style={{
              transform: `scale(${watchSize / 50}) rotate(${watchRotation}deg)`,
            }}
            animate={{ scale: [0.9, 1, 0.9] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <img
              src={currentWatch.image}
              alt={currentWatch.name}
              className="w-32 h-32 md:w-40 md:h-40 object-contain filter drop-shadow-2xl"
            />
            {/* Watch glow effect */}
            <div className="absolute inset-0 bg-gold-400/20 rounded-full blur-xl animate-pulse"></div>
          </motion.div>
        </div>

        {/* Positioning Guide */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-48 h-48 border-2 border-gold-400/50 rounded-full animate-pulse">
            <div className="w-full h-full border border-white/30 rounded-full m-2"></div>
          </div>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-black/80 backdrop-blur-sm p-4">
        {/* Watch Selector */}
        <div className="flex justify-center space-x-4 mb-4">
          {watchModels.map((watch) => (
            <button
              key={watch.id}
              onClick={() => setCurrentWatch(watch)}
              className={`w-12 h-12 rounded-full border-2 overflow-hidden transition-all duration-300 ${
                currentWatch.id === watch.id
                  ? 'border-gold-400 scale-110'
                  : 'border-white/30 hover:border-white/50'
              }`}
            >
              <img
                src={watch.image}
                alt={watch.name}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>

        {/* Current Watch Info */}
        <div className="text-center text-white mb-4">
          <h3 className="text-lg font-light tracking-wide">{currentWatch.name}</h3>
          <p className="text-sm text-white/70">{currentWatch.size} • {currentWatch.material} • {currentWatch.price}</p>
        </div>

        {/* Controls */}
        <div className="flex justify-center items-center space-x-6">
          {/* Size Control */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-white/70">Size</span>
            <input
              type="range"
              min="30"
              max="80"
              value={watchSize}
              onChange={(e) => setWatchSize(Number(e.target.value))}
              className="w-20 accent-gold-400"
            />
          </div>

          {/* Rotation Control */}
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setWatchRotation(watchRotation - 15)}
              variant="ghost"
              size="sm"
              className="text-white hover:text-gold-400 hover:bg-white/10"
            >
              ↺
            </Button>
            <Button
              onClick={() => setWatchRotation(watchRotation + 15)}
              variant="ghost"
              size="sm"
              className="text-white hover:text-gold-400 hover:bg-white/10"
            >
              ↻
            </Button>
          </div>

          {/* Action Buttons */}
          <Button
            onClick={captureScreenshot}
            variant="ghost"
            size="sm"
            className="text-white hover:text-gold-400 hover:bg-white/10"
          >
            <Download className="w-4 h-4" />
          </Button>

          <Button
            onClick={resetPosition}
            variant="ghost"
            size="sm"
            className="text-white hover:text-gold-400 hover:bg-white/10"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Hidden canvas for screenshots */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Watch Details Modal */}
      {showDetails && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-30 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowDetails(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg p-8 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-light text-white">{currentWatch.name}</h3>
              <Button
                onClick={() => setShowDetails(false)}
                variant="ghost"
                size="sm"
                className="text-white hover:text-gold-400"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-4 text-white/80">
              <div>
                <h4 className="text-gold-400 font-medium mb-2">Technical Specifications</h4>
                <div className="space-y-1 text-sm">
                  <p>• Case: {currentWatch.specifications.case}</p>
                  <p>• Movement: {currentWatch.specifications.movement}</p>
                  <p>• Functions: {currentWatch.specifications.functions}</p>
                  <p>• Power Reserve: {currentWatch.specifications.powerReserve}</p>
                  <p>• Water Resistance: {currentWatch.specifications.waterResistance}</p>
                  <p>• Crystal: {currentWatch.specifications.crystal}</p>
                  <p>• Strap: {currentWatch.specifications.strap}</p>
                </div>
              </div>

              <div className="pt-4 border-t border-white/20">
                <p className="text-2xl font-light text-gold-400 mb-4">{currentWatch.price}</p>
                <Button
                  className="w-full bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 
                           text-black font-medium rounded-none uppercase tracking-wider"
                  onClick={() => window.open('https://www.vacheron-constantin.com', '_blank')}
                >
                  Visit Vacheron Constantin
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default ARTryOn;

