import { useState, useEffect, useRef } from 'react';

export const useCamera = () => {
  const [stream, setStream] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const videoRef = useRef(null);

  // Enumerate available video devices
  const enumerateDevices = async () => {
    try {
      const deviceList = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = deviceList.filter(device => device.kind === 'videoinput');
      
      console.log('Available video devices:', videoDevices);
      
      // Prioritize rear cameras
      const rearCameras = videoDevices.filter(device => 
        device.label.toLowerCase().includes('back') ||
        device.label.toLowerCase().includes('rear') ||
        device.label.toLowerCase().includes('environment')
      );
      
      const frontCameras = videoDevices.filter(device => 
        device.label.toLowerCase().includes('front') ||
        device.label.toLowerCase().includes('user') ||
        device.label.toLowerCase().includes('face')
      );
      
      // Prefer rear cameras, fallback to any available camera
      const orderedDevices = [...rearCameras, ...frontCameras, ...videoDevices];
      const uniqueDevices = orderedDevices.filter((device, index, self) => 
        index === self.findIndex(d => d.deviceId === device.deviceId)
      );
      
      setDevices(uniqueDevices);
      
      // Auto-select the first rear camera or first available camera
      if (uniqueDevices.length > 0) {
        const preferredDevice = rearCameras.length > 0 ? rearCameras[0] : uniqueDevices[0];
        setSelectedDeviceId(preferredDevice.deviceId);
        console.log('Auto-selected camera:', preferredDevice.label);
      }
      
      return uniqueDevices;
    } catch (err) {
      console.error('Error enumerating devices:', err);
      setError('Failed to enumerate camera devices');
      return [];
    }
  };

  // Start camera with specific device
  const startCamera = async (deviceId = null) => {
    setIsLoading(true);
    setError(null);

    try {
      // Stop existing stream
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      const constraints = {
        video: {
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          frameRate: { ideal: 30, max: 60 },
          facingMode: deviceId ? undefined : { ideal: 'environment' },
          deviceId: deviceId ? { exact: deviceId } : undefined
        },
        audio: false
      };

      console.log('Requesting camera with constraints:', constraints);

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      // Get actual camera info
      const videoTrack = mediaStream.getVideoTracks()[0];
      const settings = videoTrack.getSettings();
      console.log('Camera started with settings:', settings);
      console.log('Camera label:', videoTrack.label);

      setStream(mediaStream);
      
      // Attach to video element
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }

      setIsLoading(false);
      return mediaStream;
    } catch (err) {
      console.error('Error starting camera:', err);
      setError(`Camera access failed: ${err.message}`);
      setIsLoading(false);
      
      // Try fallback strategies
      if (deviceId) {
        console.log('Retrying without specific device ID...');
        return startCamera(); // Retry without device constraint
      }
      
      throw err;
    }
  };

  // Switch to different camera
  const switchCamera = async (deviceId) => {
    setSelectedDeviceId(deviceId);
    return startCamera(deviceId);
  };

  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  // Initialize on mount
  useEffect(() => {
    enumerateDevices();
    
    // Request permissions to get device labels
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        stream.getTracks().forEach(track => track.stop());
        enumerateDevices(); // Re-enumerate to get labels
      })
      .catch(err => console.log('Permission request failed:', err));

    return () => {
      stopCamera();
    };
  }, []);

  // Auto-start camera when device is selected
  useEffect(() => {
    if (selectedDeviceId && !stream) {
      startCamera(selectedDeviceId);
    }
  }, [selectedDeviceId]);

  return {
    stream,
    isLoading,
    error,
    devices,
    selectedDeviceId,
    videoRef,
    startCamera,
    stopCamera,
    switchCamera,
    enumerateDevices
  };
};

