import React, { useState, useEffect } from 'react';
import { Camera, RotateCcw, Download, Settings, Info, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useCamera } from '../hooks/useCamera';
import { useWristTracking } from '../hooks/useWristTracking';
import WatchRenderer from './WatchRenderer';
import './ARInterface.css';

const ARInterface = () => {
  const [selectedWatch, setSelectedWatch] = useState('overseas');
  const [watchScale, setWatchScale] = useState(1);
  const [showInfo, setShowInfo] = useState(false);
  const [isARActive, setIsARActive] = useState(false);

  // Camera hook
  const {
    stream,
    isLoading: cameraLoading,
    error: cameraError,
    devices,
    selectedDeviceId,
    videoRef,
    startCamera,
    stopCamera,
    switchCamera
  } = useCamera();

  // Wrist tracking hook
  const {
    isInitialized: trackingInitialized,
    isTracking,
    wristData,
    error: trackingError,
    startTracking,
    stopTracking
  } = useWristTracking(videoRef.current);

  // Watch collection data
  const watchCollection = {
    overseas: {
      name: 'Overseas Self-Winding',
      size: '41mm',
      material: 'Stainless Steel',
      price: '$27,700',
      description: 'The spirit of travel embodied in a luxury sports watch'
    },
    patrimony: {
      name: 'Patrimony Moon Phase',
      size: '42.5mm', 
      material: 'White Gold',
      price: '$55,000',
      description: 'Circular perfection with moon phase complication'
    },
    traditionnelle: {
      name: 'Traditionnelle Manual-Winding',
      size: '38mm',
      material: 'Rose Gold', 
      price: '$32,000',
      description: 'Pure horological tradition in contemporary form'
    },
    historiques: {
      name: 'Historiques American 1921',
      size: '40mm',
      material: 'Platinum',
      price: '$78,000', 
      description: 'Iconic cushion-shaped case from 1921'
    }
  };

  // Start AR experience
  const startAR = async () => {
    try {
      setIsARActive(true);
      if (!stream) {
        await startCamera();
      }
      startTracking();
    } catch (err) {
      console.error('Failed to start AR:', err);
    }
  };

  // Stop AR experience
  const stopAR = () => {
    setIsARActive(false);
    stopTracking();
    stopCamera();
  };

  // Take screenshot
  const takeScreenshot = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      
      ctx.drawImage(videoRef.current, 0, 0);
      
      // Download the screenshot
      const link = document.createElement('a');
      link.download = `vacheron-constantin-${selectedWatch}-${Date.now()}.png`;
      link.href = canvas.toDataURL();
      link.click();
    }
  };

  // Switch watch model
  const switchWatch = (watchId) => {
    setSelectedWatch(watchId);
  };

  // Adjust watch scale
  const adjustScale = (delta) => {
    setWatchScale(prev => Math.max(0.5, Math.min(2.0, prev + delta)));
  };

  return (
    <div className="ar-interface luxury-gradient min-h-screen relative overflow-hidden">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-40 p-4">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold gold-accent">
            VACHERON CONSTANTIN
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInfo(!showInfo)}
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Camera Feed */}
      {stream && (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="camera-feed"
        />
      )}

      {/* AR Canvas Overlay */}
      {isARActive && trackingInitialized && (
        <WatchRenderer
          wristData={wristData}
          selectedWatch={selectedWatch}
          isVisible={isTracking}
          watchScale={watchScale}
          className="ar-canvas"
        />
      )}

      {/* Wrist Guide (when not tracking) */}
      {isARActive && !isTracking && (
        <div className="ar-overlay">
          <div className="wrist-guide">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center cream-text">
                <div className="text-sm font-medium">Position your wrist</div>
                <div className="text-xs opacity-75">in the center</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {(cameraLoading || !trackingInitialized) && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-50">
          <div className="text-center">
            <div className="loading-spinner mx-auto mb-4"></div>
            <div className="cream-text">
              {cameraLoading ? 'Initializing Camera...' : 'Loading AR System...'}
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {(cameraError || trackingError) && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/90 z-50">
          <Card className="p-6 max-w-md mx-4">
            <div className="text-center">
              <div className="text-destructive mb-2">Camera Access Required</div>
              <div className="text-sm text-muted-foreground mb-4">
                {cameraError || trackingError}
              </div>
              <Button onClick={startAR} className="w-full">
                <Camera className="w-4 h-4 mr-2" />
                Retry Camera Access
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Watch Selection */}
      {isARActive && (
        <div className="absolute bottom-20 left-4 right-4 z-30">
          <div className="flex gap-2 justify-center mb-4">
            {Object.entries(watchCollection).map(([id, watch]) => (
              <Button
                key={id}
                variant={selectedWatch === id ? "default" : "outline"}
                size="sm"
                onClick={() => switchWatch(id)}
                className="min-w-0 px-3"
              >
                <div className="text-center">
                  <div className="text-xs font-medium">{watch.name.split(' ')[0]}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Controls */}
      {isARActive && (
        <div className="watch-controls">
          <Button
            variant="outline"
            size="sm"
            onClick={() => adjustScale(-0.1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            -
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={takeScreenshot}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <Download className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => adjustScale(0.1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            +
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWatchScale(1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Start AR Button */}
      {!isARActive && (
        <div className="absolute inset-0 flex items-center justify-center z-30">
          <Card className="p-8 text-center max-w-md mx-4">
            <div className="mb-6">
              <div className="text-2xl font-bold gold-accent mb-2">
                AR Watch Try-On
              </div>
              <div className="text-muted-foreground">
                Experience Vacheron Constantin timepieces in augmented reality
              </div>
            </div>
            
            <Button 
              onClick={startAR} 
              size="lg" 
              className="w-full mb-4"
              disabled={cameraLoading}
            >
              <Zap className="w-5 h-5 mr-2" />
              Start AR Experience
            </Button>
            
            <div className="text-xs text-muted-foreground">
              Camera access required for AR functionality
            </div>
          </Card>
        </div>
      )}

      {/* Watch Info Panel */}
      {showInfo && selectedWatch && (
        <div className="absolute top-16 right-4 z-40">
          <Card className="p-4 max-w-xs">
            <div className="space-y-2">
              <div className="font-semibold gold-accent">
                {watchCollection[selectedWatch].name}
              </div>
              <div className="flex gap-2">
                <Badge variant="secondary">{watchCollection[selectedWatch].size}</Badge>
                <Badge variant="outline">{watchCollection[selectedWatch].material}</Badge>
              </div>
              <div className="text-sm text-muted-foreground">
                {watchCollection[selectedWatch].description}
              </div>
              <div className="text-lg font-bold gold-accent">
                {watchCollection[selectedWatch].price}
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Status Indicators */}
      {isARActive && (
        <div className="absolute top-16 left-4 z-40 space-y-2">
          <Badge variant={stream ? "default" : "destructive"}>
            Camera: {stream ? "Active" : "Inactive"}
          </Badge>
          <Badge variant={isTracking ? "default" : "secondary"}>
            Tracking: {isTracking ? "Detected" : "Searching"}
          </Badge>
          {devices.length > 1 && (
            <div className="space-y-1">
              {devices.map((device, index) => (
                <Button
                  key={device.deviceId}
                  variant={device.deviceId === selectedDeviceId ? "default" : "outline"}
                  size="sm"
                  onClick={() => switchCamera(device.deviceId)}
                  className="text-xs w-full"
                >
                  Camera {index + 1}
                </Button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Exit AR Button */}
      {isARActive && (
        <div className="absolute top-4 right-4 z-40">
          <Button
            variant="outline"
            size="sm"
            onClick={stopAR}
            className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            Exit AR
          </Button>
        </div>
      )}
    </div>
  );
};

export default ARInterface;

