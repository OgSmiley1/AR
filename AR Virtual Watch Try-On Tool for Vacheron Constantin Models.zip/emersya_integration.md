# Emersya 3D Integration Details

## How to Embed Emersya 3D Viewers

### Method 1: Using iframe
```html
<iframe
  src="https://emersya.com/showcase/PRODUCT_CODE"
  width="90%"
  height="500px"
  webkitallowfullscreen
  allow='camera; gyroscope; accelerometer; magnetometer; fullscreen;'>
</iframe>
```

### Method 2: Using script
```html
<script
  type="text/javascript"
  src="https://cdn.emersya.com/f/emersyaLoader.js"
  id="emersya"
  routing="PRODUCT_CODE"
  containerId="VIEWER_CONTAINER_ID">
</script>
```

## Key Features
- Interactive 3D viewing from all angles
- Unlimited zoom capability
- Multiple colorway/variant support
- AR capabilities
- No plugin required
- Mobile compatible

## Vacheron Constantin Implementation
- Uses Emersya for watch strap customization
- Photo-realistic 3D rendering
- Multiple watch strap options
- Interactive exploration

## For AR Try-On Implementation
- We'll create mock 3D viewer containers for each watch model
- Implement AR camera functionality (back view as specified)
- Allow users to switch between different watch models
- Integrate with responsive design for mobile/desktop compatibility

