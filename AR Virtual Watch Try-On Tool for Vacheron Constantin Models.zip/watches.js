// Watch models data
import overseasImage from '../assets/images/overseas-pink-gold.jpg';
import patrimonyImage from '../assets/images/patrimony-moon-phase.jpg';
import traditionnelleImage from '../assets/images/traditionnelle-manual.jpg';
import american1921Image from '../assets/images/american-1921.jpg';

export const watchModels = [
  {
    id: 'overseas',
    name: 'Overseas Self-Winding',
    collection: 'Overseas',
    size: '41mm',
    material: 'Pink Gold',
    price: '$65,000',
    image: overseasImage,
    description: 'Self-winding movement, sporty luxury design',
    specifications: {
      case: '41mm Pink Gold',
      movement: 'Caliber 5100',
      functions: 'Hours, minutes, seconds, date',
      powerReserve: '60 hours',
      waterResistance: '150m',
      crystal: 'Sapphire',
      strap: 'Pink gold bracelet'
    },
    backgroundColor: 'from-amber-900 to-yellow-800'
  },
  {
    id: 'patrimony',
    name: 'Patrimony Moon Phase Retrograde Date',
    collection: 'Patrimony',
    size: '42.5mm',
    material: 'White Gold',
    price: '$53,000',
    image: patrimonyImage,
    description: 'Moon phase, retrograde date, elegant dress watch',
    specifications: {
      case: '42.5mm White Gold',
      movement: 'Caliber 2460 R31L',
      functions: 'Hours, minutes, moon phase, retrograde date',
      powerReserve: '40 hours',
      waterResistance: '30m',
      crystal: 'Sapphire',
      strap: 'Alligator leather'
    },
    backgroundColor: 'from-purple-900 to-indigo-800'
  },
  {
    id: 'traditionnelle',
    name: 'Traditionnelle Manual-Winding',
    collection: 'Traditionnelle',
    size: '38mm',
    material: 'Pink Gold',
    price: '$27,200',
    image: traditionnelleImage,
    description: 'Manual-winding, classic design, traditional aesthetics',
    specifications: {
      case: '38mm Pink Gold',
      movement: 'Caliber 4400',
      functions: 'Hours, minutes',
      powerReserve: '65 hours',
      waterResistance: '30m',
      crystal: 'Sapphire',
      strap: 'Alligator leather'
    },
    backgroundColor: 'from-teal-900 to-cyan-800'
  },
  {
    id: 'american1921',
    name: 'Historiques American 1921',
    collection: 'Historiques',
    size: '40x40mm',
    material: 'White Gold',
    price: '$42,600',
    image: american1921Image,
    description: 'Unique cushion case, vintage-inspired design, distinctive dial layout',
    specifications: {
      case: '40x40mm White Gold',
      movement: 'Caliber 4400',
      functions: 'Hours, minutes, small seconds',
      powerReserve: '65 hours',
      waterResistance: '30m',
      crystal: 'Sapphire',
      strap: 'Alligator leather'
    },
    backgroundColor: 'from-slate-900 to-gray-800'
  }
];

