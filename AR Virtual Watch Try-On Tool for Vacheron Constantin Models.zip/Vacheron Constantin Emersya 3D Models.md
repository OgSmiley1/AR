# Vacheron Constantin Emersya 3D Models

## Available Models Found

### 1. Overseas Collection
- **URL**: https://www.emersya.com/vacheron-constantin-overseas-watch/
- **Features**: Interactive 3D view, Multiple colorways, Unlimited zoom
- **Description**: Overseas range with intricate mechanism details

### 2. Egerie Collection  
- **URL**: https://www.emersya.com/vacheron-constantin-egerie-watch/
- **Features**: State-of-the-art 3D viewer for luxury timepieces

### 3. Traditionnelle Collection
- **URL**: https://www.emersya.com/vacheron-constantin-traditionnelle-watch/
- **Features**: Interactive 3D with detailed exploration capabilities

### 4. Watch Straps Customization
- **URL**: https://www.emersya.com/vacheron-constantin-watches/
- **Features**: 3D strap customization experience

## Technical Integration Details

### Emersya 3D Viewer Specifications
- **Technology**: Real-time 3D rendering
- **Format**: Likely GLTF/GLB models
- **Features**: 
  - 360-degree rotation
  - Unlimited zoom
  - Multiple material variants
  - Real-time lighting
  - High-quality textures

### Watch Dimensions (From VC Website)
- **Patrimony Moon Phase**: 42.5mm diameter, 9.7mm thickness
- **Case Materials**: White Gold, Rose Gold, Stainless Steel
- **Water Resistance**: 3 bar (30m)
- **Strap Materials**: Alligator leather, Metal bracelet

## Extraction Strategy for AR Implementation

### 1. Model Access Methods
- **Direct Integration**: Use Emersya's embed API if available
- **Model Extraction**: Reverse engineer 3D model URLs from viewer
- **Asset Recreation**: Create high-quality 3D models based on specifications

### 2. Required Conversions for AR
- **Format**: Convert to GLTF/GLB for Three.js compatibility
- **Scale**: Adjust to real-world dimensions (42.5mm diameter)
- **Materials**: Implement PBR materials for realistic rendering
- **Optimization**: Reduce polygon count for mobile performance

### 3. AR-Specific Adaptations
- **Wrist Sizing**: Scale models to fit detected wrist dimensions
- **Occlusion**: Add invisible wrist mesh for proper depth handling
- **Lighting**: Implement environment-based lighting estimation
- **Physics**: Add subtle movement and gravity effects

## Implementation Plan

1. **Extract 3D Models**: Get GLTF/GLB files from Emersya viewers
2. **Optimize for AR**: Reduce complexity while maintaining quality
3. **Create Material System**: PBR shaders for realistic appearance
4. **Implement Scaling**: Dynamic sizing based on wrist detection
5. **Add Interactions**: Rotation, model switching, screenshot capture

This will provide the authentic Vacheron Constantin watch models with proper dimensions and materials for the AR try-on experience.

