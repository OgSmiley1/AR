import { useState } from 'react';
import LandingPage from './components/LandingPage.jsx';
import WatchSelection from './components/WatchSelection.jsx';
import ARTryOn from './components/ARTryOn.jsx';
import './App.css';

function App() {
  const [currentView, setCurrentView] = useState('landing'); // 'landing', 'selection', 'ar'
  const [selectedWatch, setSelectedWatch] = useState(null);

  const handleStartExperience = () => {
    setCurrentView('selection');
  };

  const handleSelectWatch = (watch) => {
    setSelectedWatch(watch);
    setCurrentView('ar');
  };

  const handleBackToLanding = () => {
    setCurrentView('landing');
    setSelectedWatch(null);
  };

  const handleBackToSelection = () => {
    setCurrentView('selection');
    setSelectedWatch(null);
  };

  return (
    <div className="App">
      {currentView === 'landing' && (
        <LandingPage onStartExperience={handleStartExperience} />
      )}
      
      {currentView === 'selection' && (
        <WatchSelection
          onSelectWatch={handleSelectWatch}
          onBack={handleBackToLanding}
        />
      )}
      
      {currentView === 'ar' && selectedWatch && (
        <ARTryOn
          selectedWatch={selectedWatch}
          onBack={handleBackToSelection}
          onSelectDifferentWatch={handleBackToSelection}
        />
      )}
    </div>
  );
}

export default App;

