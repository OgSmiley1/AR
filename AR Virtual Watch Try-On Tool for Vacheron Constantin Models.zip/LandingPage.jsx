import { Button } from '@/components/ui/button.jsx';
import { motion } from 'framer-motion';

const LandingPage = ({ onStartExperience }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-black relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-2 h-2 bg-gold-400 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-32 w-1 h-1 bg-white rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-1/4 w-1.5 h-1.5 bg-gold-300 rounded-full animate-pulse delay-2000"></div>
        <div className="absolute bottom-20 right-20 w-1 h-1 bg-white rounded-full animate-pulse delay-3000"></div>
        
        {/* Geometric patterns */}
        <motion.div
          className="absolute top-1/4 left-1/3 w-32 h-32 border border-gold-400/20 rotate-45"
          animate={{ rotate: [45, 90, 45] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/3 w-24 h-24 border border-white/10 rotate-12"
          animate={{ rotate: [12, 57, 12] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 md:p-8">
        <div className="text-2xl md:text-3xl font-light text-white tracking-wider">
          VACHERON CONSTANTIN
        </div>
        <nav className="hidden md:flex space-x-8 text-sm text-white/80 uppercase tracking-wide">
          <a href="#" className="hover:text-gold-400 transition-colors">Watches</a>
          <a href="#" className="hover:text-gold-400 transition-colors">Maison</a>
          <a href="#" className="hover:text-gold-400 transition-colors">Services</a>
          <a href="#" className="hover:text-gold-400 transition-colors">Contact</a>
        </nav>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-thin text-white mb-4 tracking-wide">
            VIRTUAL WATCH
          </h1>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-thin text-white mb-8 tracking-wide">
            TRY-ON EXPERIENCE
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1 }}
          className="text-lg md:text-xl text-white/80 mb-12 max-w-2xl leading-relaxed"
        >
          Discover Vacheron Constantin timepieces in Augmented Reality.
          Experience the craftsmanship and elegance of Swiss haute horlogerie
          from the comfort of your home.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 1.5 }}
        >
          <Button
            onClick={onStartExperience}
            className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 
                     text-black font-medium px-8 py-4 text-lg rounded-none border-none 
                     transform hover:scale-105 transition-all duration-300 shadow-2xl
                     uppercase tracking-wider"
          >
            Start Try-On Experience
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 2 }}
          className="mt-16 text-xs text-white/60 uppercase tracking-widest"
        >
          Since 1755 • Swiss Luxury Watchmaking
        </motion.div>
      </div>

      {/* Bottom decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-400/50 to-transparent"></div>
    </div>
  );
};

export default LandingPage;

