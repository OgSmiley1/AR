import React, { useState, useEffect, useRef } from 'react';
import { Camera, RotateCcw, Download, Settings, Info, Zap, Play } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import WatchRenderer from './WatchRenderer';

const MockARInterface = () => {
  const [selectedWatch, setSelectedWatch] = useState('overseas');
  const [watchScale, setWatchScale] = useState(1);
  const [showInfo, setShowInfo] = useState(false);
  const [isARActive, setIsARActive] = useState(false);
  const [isTracking, setIsTracking] = useState(false);
  const [mockWristData, setMockWristData] = useState(null);
  const videoRef = useRef(null);

  // Watch collection data
  const watchCollection = {
    overseas: {
      name: 'Overseas Self-Winding',
      size: '41mm',
      material: 'Stainless Steel',
      price: '$27,700',
      description: 'The spirit of travel embodied in a luxury sports watch'
    },
    patrimony: {
      name: 'Patrimony Moon Phase',
      size: '42.5mm', 
      material: 'White Gold',
      price: '$55,000',
      description: 'Circular perfection with moon phase complication'
    },
    traditionnelle: {
      name: 'Traditionnelle Manual-Winding',
      size: '38mm',
      material: 'Rose Gold', 
      price: '$32,000',
      description: 'Pure horological tradition in contemporary form'
    },
    historiques: {
      name: 'Historiques American 1921',
      size: '40mm',
      material: 'Platinum',
      price: '$78,000', 
      description: 'Iconic cushion-shaped case from 1921'
    }
  };

  // Mock wrist tracking simulation
  useEffect(() => {
    if (isARActive) {
      const interval = setInterval(() => {
        // Simulate wrist movement
        const time = Date.now() * 0.001;
        const mockData = {
          position: {
            x: 0.5 + Math.sin(time * 0.5) * 0.1,
            y: 0.5 + Math.cos(time * 0.3) * 0.1,
            z: 0.2 + Math.sin(time * 0.2) * 0.05
          },
          rotation: {
            x: Math.sin(time * 0.4) * 0.2,
            y: Math.cos(time * 0.3) * 0.2,
            z: Math.sin(time * 0.6) * 0.1
          },
          wristWidth: 0.15 + Math.sin(time * 0.1) * 0.02,
          confidence: 0.8 + Math.sin(time * 2) * 0.1,
          isRightHand: true,
          timestamp: Date.now()
        };
        setMockWristData(mockData);
        setIsTracking(true);
      }, 50); // 20 FPS

      return () => clearInterval(interval);
    } else {
      setIsTracking(false);
      setMockWristData(null);
    }
  }, [isARActive]);

  // Start AR experience
  const startAR = () => {
    setIsARActive(true);
  };

  // Stop AR experience
  const stopAR = () => {
    setIsARActive(false);
  };

  // Take screenshot
  const takeScreenshot = () => {
    // Create a canvas to capture the current state
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 1280;
    canvas.height = 720;
    
    // Fill with dark background
    ctx.fillStyle = '#1a2332';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add some mock camera feed effect
    ctx.fillStyle = 'rgba(212, 175, 55, 0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add text overlay
    ctx.fillStyle = '#D4AF37';
    ctx.font = '24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Vacheron Constantin AR Try-On', canvas.width / 2, 50);
    ctx.fillText(`${watchCollection[selectedWatch].name}`, canvas.width / 2, canvas.height - 50);
    
    // Download the screenshot
    const link = document.createElement('a');
    link.download = `vacheron-constantin-${selectedWatch}-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  // Switch watch model
  const switchWatch = (watchId) => {
    setSelectedWatch(watchId);
  };

  // Adjust watch scale
  const adjustScale = (delta) => {
    setWatchScale(prev => Math.max(0.5, Math.min(2.0, prev + delta)));
  };

  return (
    <div className="ar-interface luxury-gradient min-h-screen relative overflow-hidden">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-40 p-4">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold gold-accent">
            VACHERON CONSTANTIN
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInfo(!showInfo)}
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mock Camera Feed Background */}
      {isARActive && (
        <div className="camera-feed bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900">
          {/* Simulated camera noise/grain effect */}
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.4'/%3E%3C/svg%3E")`,
            }}
          />
          
          {/* Mock hand/wrist area */}
          {isTracking && mockWristData && (
            <div 
              className="absolute w-32 h-32 rounded-full border-2 border-primary/50 bg-primary/10"
              style={{
                left: `${mockWristData.position.x * 100}%`,
                top: `${mockWristData.position.y * 100}%`,
                transform: 'translate(-50%, -50%)',
                animation: 'pulse 2s infinite'
              }}
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-amber-200/20 to-amber-600/20" />
            </div>
          )}
        </div>
      )}

      {/* AR Canvas Overlay */}
      {isARActive && (
        <WatchRenderer
          wristData={mockWristData}
          selectedWatch={selectedWatch}
          isVisible={isTracking}
          watchScale={watchScale}
          className="ar-canvas"
        />
      )}

      {/* Wrist Guide (when not tracking) */}
      {isARActive && !isTracking && (
        <div className="ar-overlay">
          <div className="wrist-guide">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center cream-text">
                <div className="text-sm font-medium">Position your wrist</div>
                <div className="text-xs opacity-75">in the center</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Watch Selection */}
      {isARActive && (
        <div className="absolute bottom-20 left-4 right-4 z-30">
          <div className="flex gap-2 justify-center mb-4 flex-wrap">
            {Object.entries(watchCollection).map(([id, watch]) => (
              <Button
                key={id}
                variant={selectedWatch === id ? "default" : "outline"}
                size="sm"
                onClick={() => switchWatch(id)}
                className="min-w-0 px-3"
              >
                <div className="text-center">
                  <div className="text-xs font-medium">{watch.name.split(' ')[0]}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Controls */}
      {isARActive && (
        <div className="watch-controls">
          <Button
            variant="outline"
            size="sm"
            onClick={() => adjustScale(-0.1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            -
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={takeScreenshot}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <Download className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => adjustScale(0.1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            +
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWatchScale(1)}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Start AR Button */}
      {!isARActive && (
        <div className="absolute inset-0 flex items-center justify-center z-30">
          <Card className="p-8 text-center max-w-md mx-4">
            <div className="mb-6">
              <div className="text-2xl font-bold gold-accent mb-2">
                AR Watch Try-On
              </div>
              <div className="text-muted-foreground mb-4">
                Experience Vacheron Constantin timepieces in augmented reality
              </div>
              <div className="text-xs text-amber-600 bg-amber-50 p-2 rounded mb-4">
                Demo Mode: Simulated AR experience without camera
              </div>
            </div>
            
            <Button 
              onClick={startAR} 
              size="lg" 
              className="w-full mb-4"
            >
              <Play className="w-5 h-5 mr-2" />
              Start AR Demo
            </Button>
            
            <div className="text-xs text-muted-foreground">
              Interactive 3D watch models with realistic rendering
            </div>
          </Card>
        </div>
      )}

      {/* Watch Info Panel */}
      {showInfo && selectedWatch && (
        <div className="absolute top-16 right-4 z-40">
          <Card className="p-4 max-w-xs">
            <div className="space-y-2">
              <div className="font-semibold gold-accent">
                {watchCollection[selectedWatch].name}
              </div>
              <div className="flex gap-2">
                <Badge variant="secondary">{watchCollection[selectedWatch].size}</Badge>
                <Badge variant="outline">{watchCollection[selectedWatch].material}</Badge>
              </div>
              <div className="text-sm text-muted-foreground">
                {watchCollection[selectedWatch].description}
              </div>
              <div className="text-lg font-bold gold-accent">
                {watchCollection[selectedWatch].price}
              </div>
              <Button 
                size="sm" 
                className="w-full mt-2"
                onClick={() => window.open('https://www.vacheron-constantin.com', '_blank')}
              >
                View on Official Site
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Status Indicators */}
      {isARActive && (
        <div className="absolute top-16 left-4 z-40 space-y-2">
          <Badge variant="default">
            Demo Mode: Active
          </Badge>
          <Badge variant={isTracking ? "default" : "secondary"}>
            Tracking: {isTracking ? "Simulated" : "Initializing"}
          </Badge>
          <Badge variant="outline">
            Scale: {Math.round(watchScale * 100)}%
          </Badge>
        </div>
      )}

      {/* Exit AR Button */}
      {isARActive && (
        <div className="absolute top-4 right-4 z-40">
          <Button
            variant="outline"
            size="sm"
            onClick={stopAR}
            className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            Exit AR
          </Button>
        </div>
      )}
    </div>
  );
};

export default MockARInterface;

