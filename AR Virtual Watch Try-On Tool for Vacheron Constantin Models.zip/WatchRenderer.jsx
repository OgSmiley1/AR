import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useGLTF, PerspectiveCamera, Environment } from '@react-three/drei';
import * as THREE from 'three';

// Realistic Watch Model Component
const RealisticWatchModel = ({ 
  position = [0, 0, 0], 
  rotation = [0, 0, 0], 
  scale = 1,
  modelUrl,
  wristData,
  visible = true 
}) => {
  const meshRef = useRef();
  const groupRef = useRef();
  
  // Load GLTF model (placeholder for now, will be replaced with actual Vacheron Constantin models)
  const { scene } = useGLTF('/models/watch-placeholder.glb', true);
  
  // Create a procedural watch model if GLTF fails to load
  const createProceduralWatch = () => {
    const group = new THREE.Group();
    
    // Watch case
    const caseGeometry = new THREE.CylinderGeometry(0.02, 0.02, 0.008, 32);
    const caseMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xC0C0C0,
      metalness: 0.9,
      roughness: 0.1,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1
    });
    const watchCase = new THREE.Mesh(caseGeometry, caseMaterial);
    watchCase.rotation.x = Math.PI / 2;
    group.add(watchCase);
    
    // Watch face
    const faceGeometry = new THREE.CylinderGeometry(0.018, 0.018, 0.001, 32);
    const faceMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xF8F8F8,
      metalness: 0.0,
      roughness: 0.1
    });
    const watchFace = new THREE.Mesh(faceGeometry, faceMaterial);
    watchFace.rotation.x = Math.PI / 2;
    watchFace.position.z = 0.005;
    group.add(watchFace);
    
    // Watch hands
    const hourHandGeometry = new THREE.BoxGeometry(0.001, 0.01, 0.0005);
    const minuteHandGeometry = new THREE.BoxGeometry(0.0008, 0.015, 0.0005);
    const handMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x333333,
      metalness: 0.8,
      roughness: 0.2
    });
    
    const hourHand = new THREE.Mesh(hourHandGeometry, handMaterial);
    const minuteHand = new THREE.Mesh(minuteHandGeometry, handMaterial);
    
    hourHand.position.set(0, 0.005, 0.006);
    minuteHand.position.set(0, 0.0075, 0.006);
    
    group.add(hourHand);
    group.add(minuteHand);
    
    // Watch band
    const bandGeometry = new THREE.TorusGeometry(0.025, 0.003, 8, 16, Math.PI * 1.5);
    const bandMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x8B4513,
      roughness: 0.8,
      metalness: 0.1
    });
    
    const band1 = new THREE.Mesh(bandGeometry, bandMaterial);
    const band2 = new THREE.Mesh(bandGeometry, bandMaterial);
    
    band1.rotation.z = Math.PI / 2;
    band2.rotation.z = -Math.PI / 2;
    
    group.add(band1);
    group.add(band2);
    
    return group;
  };

  // Animation and positioning based on wrist data
  useFrame((state, delta) => {
    if (!groupRef.current) return;

    if (wristData && visible) {
      // Convert normalized coordinates to 3D space
      const x = (wristData.position.x - 0.5) * 2;
      const y = -(wristData.position.y - 0.5) * 2;
      const z = wristData.position.z * 0.5;

      // Apply position with smooth interpolation
      groupRef.current.position.lerp(new THREE.Vector3(x, y, z), 0.1);
      
      // Apply rotation based on wrist orientation
      if (wristData.rotation) {
        const targetRotation = new THREE.Euler(
          wristData.rotation.x,
          wristData.rotation.y,
          wristData.rotation.z
        );
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, targetRotation.x, 0.1);
        groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetRotation.y, 0.1);
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, targetRotation.z, 0.1);
      }

      // Scale based on wrist width
      if (wristData.wristWidth) {
        const targetScale = Math.max(0.5, Math.min(2.0, wristData.wristWidth * 3));
        groupRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.05);
      }

      // Animate watch hands (time-based)
      const time = state.clock.getElapsedTime();
      if (meshRef.current) {
        // Subtle rotation animation
        meshRef.current.rotation.y = Math.sin(time * 0.5) * 0.1;
      }
    }

    // Fade in/out based on visibility
    if (groupRef.current.material) {
      const targetOpacity = visible ? 1 : 0;
      groupRef.current.material.opacity = THREE.MathUtils.lerp(
        groupRef.current.material.opacity || 0, 
        targetOpacity, 
        0.1
      );
    }
  });

  useEffect(() => {
    if (groupRef.current) {
      // Clear existing children
      while (groupRef.current.children.length > 0) {
        groupRef.current.remove(groupRef.current.children[0]);
      }

      // Add watch model
      let watchModel;
      if (scene) {
        watchModel = scene.clone();
      } else {
        watchModel = createProceduralWatch();
      }

      // Scale the model appropriately (42.5mm diameter = ~0.0425m)
      watchModel.scale.setScalar(scale * 4); // Increased scale for visibility
      groupRef.current.add(watchModel);
      meshRef.current = watchModel;
    }
  }, [scene, scale]);

  return (
    <group ref={groupRef} position={position} rotation={rotation} visible={visible}>
      {/* Additional lighting for the watch */}
      <pointLight position={[0.1, 0.1, 0.1]} intensity={0.5} color={0xffffff} />
    </group>
  );
};

// Main Watch Renderer Component
const WatchRenderer = ({ 
  wristData, 
  selectedWatch = 'overseas',
  isVisible = true,
  watchScale = 1,
  className = ''
}) => {
  const [watchModels] = useState({
    overseas: '/models/overseas.glb',
    patrimony: '/models/patrimony.glb',
    traditionnelle: '/models/traditionnelle.glb',
    historiques: '/models/historiques.glb'
  });

  return (
    <div className={`ar-canvas ${className}`}>
      <Canvas
        camera={{ position: [0, 0, 1], fov: 75 }}
        style={{ width: '100%', height: '100%' }}
      >
        {/* Lighting setup for realistic rendering */}
        <ambientLight intensity={0.4} />
        <directionalLight 
          position={[10, 10, 5]} 
          intensity={1} 
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />
        <pointLight position={[-10, -10, -5]} intensity={0.3} color={0x4444ff} />
        
        {/* Environment for reflections */}
        <Environment preset="studio" />
        
        {/* Watch Model */}
        <RealisticWatchModel
          modelUrl={watchModels[selectedWatch]}
          wristData={wristData}
          visible={isVisible}
          scale={watchScale}
        />
        
        {/* Camera controls for debugging (can be removed in production) */}
        <PerspectiveCamera makeDefault position={[0, 0, 1]} />
      </Canvas>
    </div>
  );
};

// Preload watch models
useGLTF.preload('/models/overseas.glb');
useGLTF.preload('/models/patrimony.glb');
useGLTF.preload('/models/traditionnelle.glb');
useGLTF.preload('/models/historiques.glb');

export default WatchRenderer;

