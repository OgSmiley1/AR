# Vacheron Constantin AR Try-On Website - Wireframes

## Screen 1: Landing Page
```
┌─────────────────────────────────────────────────────────────┐
│  [VC Logo]                    [Menu] [Search] [Cart] [Login] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│              [Animated Background - Celestial]              │
│                                                             │
│                 VIRTUAL WATCH TRY-ON                        │
│                     EXPERIENCE                              │
│                                                             │
│           Discover Vacheron Constantin timepieces           │
│                      in Augmented Reality                   │
│                                                             │
│              [START TRY-ON EXPERIENCE]                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Screen 2: Watch Selection Interface
```
┌─────────────────────────────────────────────────────────────┐
│  [VC Logo]                    [Menu] [Search] [Cart] [Login] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                    SELECT YOUR TIMEPIECE                    │
│                                                             │
│    ┌─────────────────┐    ┌─────────────────┐               │
│    │   [Watch Img]   │    │   [Watch Img]   │               │
│    │  Overseas       │    │  Patrimony      │               │
│    │  Self-Winding   │    │  Moon Phase     │               │
│    │  $65,000        │    │  $53,000        │               │
│    │  [TRY ON]       │    │  [TRY ON]       │               │
│    └─────────────────┘    └─────────────────┘               │
│                                                             │
│    ┌─────────────────┐    ┌─────────────────┐               │
│    │   [Watch Img]   │    │   [Watch Img]   │               │
│    │ Traditionnelle  │    │  American 1921  │               │
│    │ Manual-Winding  │    │  Historiques    │               │
│    │  $27,200        │    │  $42,600        │               │
│    │  [TRY ON]       │    │  [TRY ON]       │               │
│    └─────────────────┘    └─────────────────┘               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Screen 3: AR Try-On Experience (Desktop)
```
┌─────────────────────────────────────────────────────────────┐
│  [VC Logo]                              [X Close] [? Help]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐  ┌─────────────────────┐  ┌─────────┐  │
│  │   WATCH MODELS  │  │                     │  │ DETAILS │  │
│  │                 │  │    CAMERA VIEW      │  │         │  │
│  │ ○ Overseas      │  │                     │  │ Model:  │  │
│  │ ● Patrimony     │  │   [User's Wrist     │  │ Patri-  │  │
│  │ ○ Traditional   │  │    with AR Watch]   │  │ mony    │  │
│  │ ○ American 1921 │  │                     │  │         │  │
│  │                 │  │                     │  │ Size:   │  │
│  │   CONTROLS      │  │                     │  │ 42.5mm  │  │
│  │                 │  │                     │  │         │  │
│  │ Size: [====●==] │  │                     │  │ Price:  │  │
│  │                 │  │                     │  │ $53,000 │  │
│  │ Rotation:       │  │                     │  │         │  │
│  │ [◄] [●] [►]     │  │                     │  │ [3D     │  │
│  │                 │  │                     │  │ VIEWER] │  │
│  │ [📷 CAPTURE]    │  │                     │  │         │  │
│  │                 │  │                     │  │ [MORE   │  │
│  │ [🔄 RESET]      │  │                     │  │ INFO]   │  │
│  └─────────────────┘  └─────────────────────┘  └─────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Screen 4: AR Try-On Experience (Mobile)
```
┌─────────────────────────────┐
│ [VC Logo]        [X] [?]    │
├─────────────────────────────┤
│                             │
│        CAMERA VIEW          │
│                             │
│      [User's Wrist          │
│       with AR Watch]        │
│                             │
│                             │
│                             │
├─────────────────────────────┤
│ [●] [○] [○] [○]  [📷] [ⓘ]  │
├─────────────────────────────┤
│ Patrimony Moon Phase        │
│ 42.5mm White Gold - $53,000│
│                             │
│ Size: [====●====]           │
│                             │
│ [🔄 RESET] [3D VIEW] [BUY]  │
└─────────────────────────────┘
```

## Screen 5: 3D Viewer Modal
```
┌─────────────────────────────────────────────────────────────┐
│                                    [X Close]                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                                                             │
│                  [Interactive 3D Watch Model]              │
│                     (Emersya Integration)                   │
│                                                             │
│                                                             │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ ● Rotate to explore    ● Zoom for details              │ │
│  │ ● Multiple angles      ● High-resolution textures      │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [BACK TO AR] [SPECIFICATIONS]                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Screen 6: Watch Specifications Panel
```
┌─────────────────────────────────────────────────────────────┐
│  Patrimony Moon Phase Retrograde Date              [X]     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐  TECHNICAL SPECIFICATIONS              │
│  │                 │                                       │
│  │   [Watch Img]   │  • Case: 42.5mm White Gold            │
│  │                 │  • Movement: Caliber 2460 R31L        │
│  │                 │  • Functions: Hours, minutes, moon    │
│  └─────────────────┘    phase, retrograde date             │
│                                                             │
│                      • Power Reserve: 40 hours             │
│                      • Water Resistance: 30m               │
│                      • Crystal: Sapphire                   │
│                      • Strap: Alligator leather            │
│                                                             │
│                      PRICE: $53,000                        │
│                                                             │
│              [BACK TO AR] [VISIT VC WEBSITE]                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Navigation Flow
```
Landing Page → Watch Selection → AR Try-On Experience
     ↓              ↓                    ↓
  [Start]      [Try On Button]    [3D Viewer Modal]
                                        ↓
                                [Specifications Panel]
                                        ↓
                                [Visit VC Website]
```

## Key Interactive Elements

### Buttons
- Primary: Gold background with white text
- Secondary: Transparent with gold border
- Hover: Subtle glow effect and scale (1.05x)

### Controls
- Sliders: Custom styled with gold accents
- Radio buttons: Gold when selected
- Toggle switches: Smooth animation

### Modals
- Backdrop: Semi-transparent black (0.8 opacity)
- Content: White background with subtle shadow
- Animation: Fade in with scale effect

### Responsive Behavior
- Desktop: Three-panel layout (controls, camera, details)
- Tablet: Two-panel layout (camera top, controls bottom)
- Mobile: Single-panel with overlay controls

This wireframe structure ensures a logical user flow while maintaining the luxury aesthetic of the Vacheron Constantin brand.

