import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';

const CameraTest = () => {
  const [stream, setStream] = useState(null);
  const [error, setError] = useState(null);
  const [devices, setDevices] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const videoRef = useRef(null);

  const enumerateDevices = async () => {
    try {
      const deviceList = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = deviceList.filter(device => device.kind === 'videoinput');
      console.log('Video devices found:', videoDevices);
      setDevices(videoDevices);
      return videoDevices;
    } catch (err) {
      console.error('Error enumerating devices:', err);
      setError('Failed to enumerate devices: ' + err.message);
      return [];
    }
  };

  const startCamera = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Stop existing stream
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      // Try different constraint strategies
      const constraints = [
        // Strategy 1: Prefer rear camera
        {
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        },
        // Strategy 2: Any camera
        {
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        },
        // Strategy 3: Basic video
        { video: true }
      ];

      let mediaStream = null;
      let lastError = null;

      for (const constraint of constraints) {
        try {
          console.log('Trying constraint:', constraint);
          mediaStream = await navigator.mediaDevices.getUserMedia(constraint);
          console.log('Camera started successfully with constraint:', constraint);
          break;
        } catch (err) {
          console.log('Constraint failed:', constraint, err.message);
          lastError = err;
        }
      }

      if (!mediaStream) {
        throw lastError || new Error('All camera strategies failed');
      }

      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }

      // Get camera info
      const videoTrack = mediaStream.getVideoTracks()[0];
      console.log('Camera settings:', videoTrack.getSettings());
      console.log('Camera label:', videoTrack.label);

    } catch (err) {
      console.error('Camera error:', err);
      setError('Camera access failed: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    enumerateDevices();
    
    // Check if getUserMedia is available
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setError('Camera API not supported in this browser');
    }

    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="min-h-screen bg-background p-4">
      <Card className="max-w-2xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">Camera Test</h1>
        
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold mb-2">Camera Status</h3>
            <div className="text-sm space-y-1">
              <div>getUserMedia supported: {navigator.mediaDevices ? '✅' : '❌'}</div>
              <div>Devices found: {devices.length}</div>
              <div>Stream active: {stream ? '✅' : '❌'}</div>
            </div>
          </div>

          {devices.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-2">Available Cameras</h3>
              <ul className="text-sm space-y-1">
                {devices.map((device, index) => (
                  <li key={device.deviceId}>
                    {index + 1}. {device.label || `Camera ${index + 1}`}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {error && (
            <div className="p-4 bg-destructive/10 border border-destructive rounded">
              <h3 className="font-semibold text-destructive mb-2">Error</h3>
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div className="flex gap-2">
            <Button 
              onClick={startCamera} 
              disabled={isLoading}
              className="flex-1"
            >
              {isLoading ? 'Starting...' : 'Start Camera'}
            </Button>
            <Button 
              onClick={stopCamera} 
              variant="outline"
              disabled={!stream}
              className="flex-1"
            >
              Stop Camera
            </Button>
          </div>

          {stream && (
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full rounded border"
                style={{ maxHeight: '400px' }}
              />
              <div className="absolute top-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
                Live Camera Feed
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default CameraTest;

