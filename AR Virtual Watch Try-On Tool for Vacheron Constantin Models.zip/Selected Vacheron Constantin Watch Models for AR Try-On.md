# Selected Vacheron Constantin Watch Models for AR Try-On

Based on the official website, I've selected 4 popular models from different collections:

## 1. Overseas Self-Winding (41mm Pink Gold)
- Collection: Overseas
- Size: 41mm
- Material: Pink Gold
- Price: $65,000
- Features: Self-winding movement, sporty luxury design

## 2. Patrimony Moon Phase Retrograde Date (42.5mm White Gold)
- Collection: Patrimony
- Size: 42.5mm
- Material: White Gold
- Price: $53,000
- Features: Moon phase, retrograde date, elegant dress watch

## 3. Traditionnelle Manual-Winding (38mm Pink Gold)
- Collection: Traditionnelle
- Size: 38mm
- Material: Pink Gold
- Price: $27,200
- Features: Manual-winding, classic design, traditional aesthetics

## 4. Historiques American 1921 (40x40mm White Gold)
- Collection: Historiques
- Size: 40x40mm
- Material: White Gold
- Price: $42,600
- Features: Unique cushion case, vintage-inspired design, distinctive dial layout

These models represent different styles and price points, providing a good variety for the AR try-on experience.

